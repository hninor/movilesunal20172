package tictactoe.unal.edu.co.androidtic_tac_toe;

import android.app.Application;



/**
 * Created by USER on 29/10/2017.
 */

public class TicTacToeApplication extends Application{

    @Override
    public void onCreate() {
        super.onCreate();

    }
}
